-("\[Kappa]"^2*(45*m1^2*DiracGamma[LorentzIndex[mu, D], D] + 
    9*m1*DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[Momentum[q, D], D] + 
    27*m1*DiracGamma[Momentum[q, D], D] . DiracGamma[LorentzIndex[mu, D], 
       D] - 36*m1*DiracGamma[Momentum[q, D], D] . 
      DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[6] - 
    36*m1*DiracGamma[Momentum[q, D], D] . DiracGamma[LorentzIndex[mu, D], 
       D] . DiracGamma[7] + 36*m1*Pair[LorentzIndex[mu, D], Momentum[q, D]] - 
    10*DiracGamma[Momentum[q, D], D]*Pair[LorentzIndex[mu, D], 
      Momentum[q, D]] + 7*DiracGamma[LorentzIndex[mu, D], D]*
     Pair[Momentum[q, D], Momentum[q, D]] - 
    18*DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[6]*
     Pair[Momentum[q, D], Momentum[q, D]] - 
    18*DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[7]*
     Pair[Momentum[q, D], Momentum[q, D]])*SMP["e"])/(1536*Epsilon*Pi^2)
