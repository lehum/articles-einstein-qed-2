-("\[Kappa]"^2*(3*m1*DiracGamma[LorentzIndex[mu, D], D] . 
      DiracGamma[Momentum[p, D], D] - 3*m1*DiracGamma[Momentum[p, D], D] . 
      DiracGamma[LorentzIndex[mu, D], D] - 
    3*DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[Momentum[l, D], D] . 
      DiracGamma[Momentum[p, D], D] + DiracGamma[LorentzIndex[mu, D], D] . 
     DiracGamma[Momentum[p, D], D] . DiracGamma[Momentum[l, D], D] - 
    DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[Momentum[p, D], D] . 
     DiracGamma[Momentum[q, D], D] + DiracGamma[Momentum[l, D], D] . 
     DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[Momentum[p, D], D] - 
    DiracGamma[Momentum[l, D], D] . DiracGamma[Momentum[p, D], D] . 
     DiracGamma[LorentzIndex[mu, D], D] - DiracGamma[Momentum[p, D], D] . 
     DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[Momentum[l, D], D] + 
    DiracGamma[Momentum[p, D], D] . DiracGamma[LorentzIndex[mu, D], D] . 
     DiracGamma[Momentum[q, D], D] + 3*DiracGamma[Momentum[p, D], D] . 
      DiracGamma[Momentum[l, D], D] . DiracGamma[LorentzIndex[mu, D], D] - 
    DiracGamma[Momentum[q, D], D] . DiracGamma[LorentzIndex[mu, D], D] . 
     DiracGamma[Momentum[p, D], D] + DiracGamma[Momentum[q, D], D] . 
     DiracGamma[Momentum[p, D], D] . DiracGamma[LorentzIndex[mu, D], D] + 
    8*DiracGamma[Momentum[p, D], D]*Pair[LorentzIndex[mu, D], 
      Momentum[l, D]] - 2*DiracGamma[Momentum[p, D], D]*
     Pair[LorentzIndex[mu, D], Momentum[q, D]] - 
    8*DiracGamma[LorentzIndex[mu, D], D]*Pair[Momentum[l, D], 
      Momentum[p, D]] + 2*DiracGamma[LorentzIndex[mu, D], D]*
     Pair[Momentum[p, D], Momentum[q, D]])*SMP["e"])/(512*Epsilon*Pi^2)
