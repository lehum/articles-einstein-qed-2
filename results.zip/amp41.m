("\[Kappa]"^2*(132*m1^2*DiracGamma[LorentzIndex[mu, D], D] + 
   27*m1*DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[Momentum[l, D], D] - 
   9*m1*DiracGamma[Momentum[l, D], D] . DiracGamma[LorentzIndex[mu, D], D] - 
   36*m1*DiracGamma[Momentum[q, D], D] . DiracGamma[LorentzIndex[mu, D], D] + 
   12*DiracGamma[LorentzIndex[mu, D], D] . DiracGamma[Momentum[l, D], D] . 
     DiracGamma[Momentum[q, D], D] + 15*DiracGamma[LorentzIndex[mu, D], D] . 
     DiracGamma[Momentum[q, D], D] . DiracGamma[Momentum[l, D], D] + 
   33*DiracGamma[Momentum[l, D], D] . DiracGamma[LorentzIndex[mu, D], D] . 
     DiracGamma[Momentum[q, D], D] + 6*DiracGamma[Momentum[l, D], D] . 
     DiracGamma[Momentum[q, D], D] . DiracGamma[LorentzIndex[mu, D], D] - 
   15*DiracGamma[Momentum[q, D], D] . DiracGamma[LorentzIndex[mu, D], D] . 
     DiracGamma[Momentum[l, D], D] + 3*DiracGamma[Momentum[q, D], D] . 
     DiracGamma[Momentum[l, D], D] . DiracGamma[LorentzIndex[mu, D], D] - 
   18*m1*Pair[LorentzIndex[mu, D], Momentum[l, D]] + 
   12*DiracGamma[Momentum[l, D], D]*Pair[LorentzIndex[mu, D], 
     Momentum[l, D]] - 4*DiracGamma[Momentum[q, D], D]*
    Pair[LorentzIndex[mu, D], Momentum[l, D]] + 
   36*m1*Pair[LorentzIndex[mu, D], Momentum[q, D]] - 
   16*DiracGamma[Momentum[l, D], D]*Pair[LorentzIndex[mu, D], 
     Momentum[q, D]] + 12*DiracGamma[Momentum[q, D], D]*
    Pair[LorentzIndex[mu, D], Momentum[q, D]] - 
   30*DiracGamma[LorentzIndex[mu, D], D]*Pair[Momentum[l, D], 
     Momentum[l, D]] - 58*DiracGamma[LorentzIndex[mu, D], D]*
    Pair[Momentum[l, D], Momentum[q, D]] - 
   30*DiracGamma[LorentzIndex[mu, D], D]*Pair[Momentum[q, D], 
     Momentum[q, D]])*SMP["e"])/(3072*Epsilon*Pi^2)
