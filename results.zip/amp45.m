(3*"\[Kappa]"^2*(DiracGamma[Momentum[p, D], D]*Pair[LorentzIndex[mu, D], 
     Momentum[l, D]] + DiracGamma[Momentum[p, D], D]*
    Pair[LorentzIndex[mu, D], Momentum[q, D]] - 
   DiracGamma[LorentzIndex[mu, D], D]*Pair[Momentum[l, D], Momentum[p, D]] - 
   DiracGamma[LorentzIndex[mu, D], D]*Pair[Momentum[p, D], Momentum[q, D]])*
  SMP["e"])/(128*Epsilon*Pi^2)
